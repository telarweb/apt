import json
import logging
from datetime import datetime, time
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.date import DateTrigger
from apscheduler.events import EVENT_JOB_EXECUTED, EVENT_JOB_ERROR
import pytz
from schedules_db import SchedulesDB
from pihole_api import PiHoleAPI


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ScheduleManager:
    """Manages APScheduler lifecycle and executes scheduled Pi-hole tasks"""

    def __init__(self, db: SchedulesDB, api: PiHoleAPI, default_timezone: str = 'UTC'):
        self.db = db
        self.api = api
        self.default_timezone = default_timezone
        self.scheduler = BackgroundScheduler(timezone=pytz.UTC)
        self.scheduler.add_listener(self._job_listener, EVENT_JOB_EXECUTED | EVENT_JOB_ERROR)

    def start(self):
        """Load schedules from DB and start scheduler"""
        logger.info("Starting schedule manager...")
        self._load_schedules()
        self.scheduler.start()
        logger.info(f"Scheduler started with {len(self.scheduler.get_jobs())} jobs")

    def stop(self):
        """Stop the scheduler gracefully"""
        logger.info("Stopping scheduler...")
        self.scheduler.shutdown()
        logger.info("Scheduler stopped")

    def add_schedule(self, schedule_record: dict):
        """Convert DB schedule to APScheduler job"""
        schedule_id = schedule_record['id']
        job_id = f"schedule_{schedule_id}"

        # Remove existing job if it exists
        try:
            self.scheduler.remove_job(job_id)
        except:
            pass

        # Create trigger
        trigger = self._create_trigger(schedule_record)

        if trigger:
            self.scheduler.add_job(
                func=self._execute_task,
                trigger=trigger,
                id=job_id,
                args=[schedule_id],
                replace_existing=True,
                misfire_grace_time=3600  # Execute if missed by up to 1 hour
            )
            logger.info(f"Added schedule {schedule_id}: {schedule_record['action']} {schedule_record['list_name']}")

    def remove_schedule(self, schedule_id: int):
        """Remove job from APScheduler"""
        job_id = f"schedule_{schedule_id}"
        try:
            self.scheduler.remove_job(job_id)
            logger.info(f"Removed schedule {schedule_id}")
        except Exception as e:
            logger.warning(f"Failed to remove schedule {schedule_id}: {e}")

    def _execute_task(self, schedule_id: int):
        """Execute the scheduled Pi-hole action"""
        schedule = self.db.get_schedule(schedule_id)
        if not schedule:
            logger.error(f"Schedule {schedule_id} not found in database")
            return

        logger.info(f"Executing schedule {schedule_id}: {schedule['action']} {schedule['list_name']}")

        try:
            enabled = (schedule['action'] == 'enable')
            self.api.set_list_enabled(schedule['list_address'], enabled)
            self.db.update_execution_status(schedule_id, 'success')
            logger.info(f"Schedule {schedule_id} executed successfully")


        except Exception as e:
            error_msg = str(e)
            self.db.update_execution_status(schedule_id, 'error', error_msg)
            logger.error(f"Schedule {schedule_id} failed: {error_msg}")

    def _create_trigger(self, schedule: dict):
        """Convert schedule record to APScheduler trigger"""
        try:
            # Get timezone
            tz_str = schedule.get('timezone') or self.default_timezone
            try:
                tz = pytz.timezone(tz_str)
            except:
                tz = pytz.UTC
                logger.warning(f"Invalid timezone {tz_str}, using UTC")

            # Parse time
            hour, minute = map(int, schedule['time'].split(':'))

            schedule_type = schedule['schedule_type']

            if schedule_type == 'daily':
                return CronTrigger(hour=hour, minute=minute, timezone=tz)

            elif schedule_type == 'weekdays':
                # Monday-Friday (0-4)
                return CronTrigger(day_of_week='0-4', hour=hour, minute=minute, timezone=tz)

            elif schedule_type == 'weekend':
                # Saturday-Sunday (5-6)
                return CronTrigger(day_of_week='5-6', hour=hour, minute=minute, timezone=tz)

            elif schedule_type == 'weekly':
                # Parse days from JSON
                if schedule['days']:
                    days = json.loads(schedule['days'])
                    day_map = {'mon': 0, 'tue': 1, 'wed': 2, 'thu': 3, 'fri': 4, 'sat': 5, 'sun': 6}
                    day_numbers = [str(day_map[d]) for d in days if d in day_map]

                    if day_numbers:
                        day_of_week = ','.join(day_numbers)
                        return CronTrigger(day_of_week=day_of_week, hour=hour, minute=minute, timezone=tz)

                logger.warning(f"Weekly schedule {schedule['id']} has no valid days")
                return None

            else:
                logger.warning(f"Unknown schedule type: {schedule_type}")
                return None

        except Exception as e:
            logger.error(f"Failed to create trigger for schedule {schedule['id']}: {e}")
            return None

    def _job_listener(self, event):
        """Handle job execution events for logging"""
        if event.exception:
            logger.error(f"Job {event.job_id} raised an exception: {event.exception}")
        else:
            logger.info(f"Job {event.job_id} executed successfully")

    def _load_schedules(self):
        """Load all enabled schedules from DB on startup"""
        schedules = self.db.get_enabled_schedules()
        logger.info(f"Loading {len(schedules)} enabled schedules from database")

        for schedule in schedules:
            try:
                self.add_schedule(schedule)
            except Exception as e:
                logger.error(f"Failed to load schedule {schedule['id']}: {e}")
