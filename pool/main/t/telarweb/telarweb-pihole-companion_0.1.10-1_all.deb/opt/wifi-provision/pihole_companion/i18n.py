import json
import os

_translations = {}
_current_locale = 'pl'


def load_translations():
    trans_dir = os.path.join(os.path.dirname(__file__), 'translations')
    for filename in os.listdir(trans_dir):
        if filename.endswith('.json'):
            locale = filename[:-5]
            with open(os.path.join(trans_dir, filename), 'r', encoding='utf-8') as f:
                _translations[locale] = json.load(f)


def get_locale():
    return _current_locale


def _(key, **kwargs):
    """Translate a key, with optional format arguments.
    Falls back to English, then to the raw key."""
    text = _translations.get(_current_locale, {}).get(key)
    if text is None:
        text = _translations.get('en', {}).get(key, key)
    if kwargs:
        text = text.format(**kwargs)
    return text
