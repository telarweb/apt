import time
import requests
from urllib.parse import quote

class PiHoleAPI:
    """
    Minimal Pi-hole API client.
    - Prefers v6 REST API (/api) with session auth
    - Falls back to v5 PHP API (/admin/api.php) for core actions

    NOTE (v6): Domains are addressed by **type/kind/domain** (no numeric ID).
    type ∈ {"allow","deny"}; kind ∈ {"exact","regex"}.
    See Pi-hole v6 docs: /api/domains/{type}/{kind}/{domain}
    """

    def __init__(self, base_url: str, password: str, timeout=6):
        self.base_url = base_url.rstrip('/')
        self.password = password
        self.timeout = timeout
        self.sid = None
        self.csrf = None
        self.last_auth = 0
        # Probe v6 – retry up to 3 times to survive transient network unavailability at boot
        self.v6 = self._probe_v6()

    def _probe_v6(self, retries=3, delay=5) -> bool:
        for attempt in range(retries):
            try:
                r = requests.get(f"{self.base_url}/api/dns/blocking", timeout=self.timeout)
                return r.status_code != 404
            except Exception:
                if attempt < retries - 1:
                    time.sleep(delay)
        return False

    # ---------- helpers ----------
    def _auth_v6(self):
        now = time.time()
        if self.sid and (now - self.last_auth) < 240:  # keep-alive ~4 min
            return
        resp = requests.post(
            f"{self.base_url}/api/auth",
            json={"password": self.password},
            timeout=self.timeout,
        )
        resp.raise_for_status()
        data = resp.json().get("session", {})
        self.sid = data.get("sid")
        self.csrf = data.get("csrf")
        self.last_auth = time.time()
        if not self.sid:
            raise RuntimeError("Failed to authenticate to Pi-hole v6 API")

    def _headers_v6(self):
        return {"X-FTL-SID": self.sid, "X-FTL-CSRF": self.csrf} if self.sid and self.csrf else {}

    # ---------- dashboard ----------
    def summary(self):
        if self.v6:
            self._auth_v6()
            r = requests.get(f"{self.base_url}/api/stats/summary", headers=self._headers_v6(), timeout=self.timeout)
            r.raise_for_status()
            j = r.json()
            
            # Extract data from nested Pi-hole v6 API response structure
            queries = j.get("queries", {})
            gravity = j.get("gravity", {})
            clients = j.get("clients", {})

            return {
                "total_queries": queries.get("total"),
                "queries_blocked": queries.get("blocked"),
                "percent_blocked": queries.get("percent_blocked"),
                "domains_on_lists": gravity.get("domains_being_blocked"),
                "active_clients": clients.get("active", 0),
                "total_clients": clients.get("total", 0),
            }
        else:
            r = requests.get(f"{self.base_url}/admin/api.php", params={"summaryRaw": "", "auth": self.password}, timeout=self.timeout)
            r.raise_for_status()
            j = r.json()

            return {
                "total_queries": j.get("dns_queries_today"),
                "queries_blocked": j.get("ads_blocked_today"),
                "percent_blocked": j.get("ads_percentage_today"),
                "domains_on_lists": j.get("domains_being_blocked"),
                "active_clients": j.get("clients_ever_seen", 0),
                "total_clients": j.get("unique_clients", 0),
            }

    def get_history(self):
        """Get history data for last 24 hours"""
        if self.v6:
            self._auth_v6()
            r = requests.get(f"{self.base_url}/api/history", headers=self._headers_v6(), timeout=self.timeout)
            r.raise_for_status()
            return r.json()
        else:
            # v5 fallback: get queries over time
            r = requests.get(f"{self.base_url}/admin/api.php", params={"overTimeDataForGraph": "", "auth": self.password}, timeout=self.timeout)
            r.raise_for_status()
            return r.json()

    # ---------- global blocking ----------
    def get_blocking(self) -> bool:
        if self.v6:
            self._auth_v6()
            r = requests.get(f"{self.base_url}/api/dns/blocking", headers=self._headers_v6(), timeout=self.timeout)
            r.raise_for_status()
            blocking = r.json().get("blocking")
            # Pi-hole v6 returns "enabled"/"disabled" strings or True/False boolean
            if isinstance(blocking, str):
                return blocking.lower() == "enabled"
            return bool(blocking)
        else:
            r = requests.get(f"{self.base_url}/admin/api.php", params={"status": "", "auth": self.password}, timeout=self.timeout)
            r.raise_for_status()
            return r.json().get("status") == "enabled"

    def set_blocking(self, enable: bool, timer_seconds: int | None = None):
        if self.v6:
            self._auth_v6()
            payload = {"blocking": bool(enable)}
            if not enable and timer_seconds:
                payload["timer"] = int(timer_seconds)
            r = requests.post(f"{self.base_url}/api/dns/blocking", json=payload, headers=self._headers_v6(), timeout=self.timeout)
            r.raise_for_status()
            return r.json() if r.text else {"ok": True}
        else:
            params = {"auth": self.password}
            if enable:
                params["enable"] = ""
            else:
                params["disable"] = int(timer_seconds) if timer_seconds else ""
            r = requests.get(f"{self.base_url}/admin/api.php", params=params, timeout=self.timeout)
            r.raise_for_status()
            return {"ok": True}

    # ---------- subscribed lists (adlists) ----------
    def lists(self):
        if not self.v6:
            raise RuntimeError("Subscribed lists API requires Pi-hole v6")
        self._auth_v6()
        r = requests.get(f"{self.base_url}/api/lists", headers=self._headers_v6(), timeout=self.timeout)
        r.raise_for_status()
        return r.json().get("lists", [])

    def add_list(self, address: str, list_type: str = "block", enabled: bool = True, groups: list[int] | None = None):
        if not self.v6:
            raise RuntimeError("Subscribed lists API requires Pi-hole v6")
        self._auth_v6()
        payload = {"address": address, "type": list_type, "enabled": bool(enabled)}
        if groups:
            payload["groups"] = groups
        r = requests.post(f"{self.base_url}/api/lists", json=payload, headers=self._headers_v6(), timeout=self.timeout)
        r.raise_for_status()
        return r.json()

    def set_list_enabled(self, address: str, enabled: bool):
        if not self.v6:
            raise RuntimeError("Subscribed lists API requires Pi-hole v6")
        self._auth_v6()

        # First, get the current list to retrieve its type and other properties
        lists = self.lists()
        current_list = next((l for l in lists if l.get('address') == address), None)

        if not current_list:
            raise RuntimeError(f"List not found: {address}")

        # Update with the new enabled state, preserving all other properties
        payload = {
            "enabled": bool(enabled),
            "type": current_list.get("type", "block")
        }

        # Preserve comment if it exists
        if current_list.get("comment"):
            payload["comment"] = current_list["comment"]

        url = f"{self.base_url}/api/lists/{quote(address, safe='')}"
        r = requests.put(url, json=payload, headers=self._headers_v6(), timeout=self.timeout)
        r.raise_for_status()
        return r.json() if r.text else {"ok": True}

    def delete_list(self, address: str):
        if not self.v6:
            raise RuntimeError("Subscribed lists API requires Pi-hole v6")
        self._auth_v6()
        r = requests.delete(f"{self.base_url}/api/lists/{quote(address, safe='')}", headers=self._headers_v6(), timeout=self.timeout)
        r.raise_for_status()
        return {"ok": True}

    # ---------- domain allow/deny ----------
    def domains(self):
        if self.v6:
            self._auth_v6()
            r = requests.get(f"{self.base_url}/api/domains", headers=self._headers_v6(), timeout=self.timeout)
            r.raise_for_status()
            return r.json().get("domains", [])
        else:
            # v5 has no clean list endpoint; return empty and rely on add/remove only
            return []

    def add_domain(self, domain: str, list_type: str = "deny", kind: str = "exact", enabled: bool = True, comment: str | None = None, groups: list[int] | None = None):
        list_type = "allow" if list_type.startswith("allow") else "deny"
        kind = "regex" if kind.startswith("regex") else "exact"
        if self.v6:
            self._auth_v6()
            payload = {}
            if enabled is not None:
                payload["enabled"] = bool(enabled)
            if comment:
                payload["comment"] = comment
            if groups:
                payload["groups"] = groups
            url = f"{self.base_url}/api/domains/{list_type}/{kind}/{quote(domain, safe='')}"
            r = requests.put(url, json=(payload or None), headers=self._headers_v6(), timeout=self.timeout)
            r.raise_for_status()
            return r.json() if r.text else {"ok": True}
        else:
            # v5 fallback: exact allow/deny only via admin API
            params = {"list": list_type, "add": domain, "auth": self.password}
            r = requests.get(f"{self.base_url}/admin/api.php", params=params, timeout=self.timeout)
            r.raise_for_status()
            return {"ok": True}

    def set_domain_enabled(self, list_type: str, kind: str, domain: str, enabled: bool):
        list_type = "allow" if list_type.startswith("allow") else "deny"
        kind = "regex" if kind.startswith("regex") else "exact"
        if not self.v6:
            raise RuntimeError("Toggling domain enabled state requires Pi-hole v6")
        self._auth_v6()

        # First, get the current domain to retrieve its comment and other properties
        domains = self.domains()
        current_domain = next((d for d in domains if d.get('domain') == domain and d.get('type') == list_type and d.get('kind') == kind), None)

        if not current_domain:
            raise RuntimeError(f"Domain not found: {domain}")

        # Update with the new enabled state, preserving all other properties
        payload = {
            "enabled": bool(enabled),
            "type": list_type,
            "kind": kind,
            "groups": [0]
        }

        # Preserve comment if it exists
        if current_domain.get("comment"):
            payload["comment"] = current_domain["comment"]

        url = f"{self.base_url}/api/domains/{list_type}/{kind}/{quote(domain, safe='')}"
        r = requests.put(url, json=payload, headers=self._headers_v6(), timeout=self.timeout)
        r.raise_for_status()
        return r.json() if r.text else {"ok": True}

    def delete_domain(self, list_type: str, kind: str, domain: str):
        list_type = "allow" if list_type.startswith("allow") else "deny"
        kind = "regex" if kind.startswith("regex") else "exact"
        if self.v6:
            self._auth_v6()
            url = f"{self.base_url}/api/domains/{list_type}/{kind}/{quote(domain, safe='')}"
            r = requests.delete(url, headers=self._headers_v6(), timeout=self.timeout)
            r.raise_for_status()
            return {"ok": True}
        else:
            # v5 fallback: exact allow/deny only
            params = {"list": list_type, "remove": domain, "auth": self.password}
            r = requests.get(f"{self.base_url}/admin/api.php", params=params, timeout=self.timeout)
            r.raise_for_status()
            return {"ok": True}
