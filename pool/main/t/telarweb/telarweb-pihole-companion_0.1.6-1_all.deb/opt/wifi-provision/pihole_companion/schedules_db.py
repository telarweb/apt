import sqlite3
import json
import os
from datetime import datetime, time, timedelta
from typing import Optional
import pytz


class SchedulesDB:
    """SQLite database layer for managing schedule data"""

    def __init__(self, db_path="data/schedules.db"):
        self.db_path = db_path
        # Ensure data directory exists
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._init_db()

    def _init_db(self):
        """Create schedules table if it doesn't exist"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS schedules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    list_address TEXT NOT NULL,
                    list_name TEXT,
                    action TEXT NOT NULL,
                    schedule_type TEXT NOT NULL,
                    time TEXT NOT NULL,
                    days TEXT,
                    timezone TEXT,
                    enabled BOOLEAN DEFAULT 1,
                    next_run TEXT,
                    last_run TEXT,
                    last_status TEXT,
                    last_error TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(list_address, schedule_type, time, days)
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_schedules_enabled ON schedules(enabled)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_schedules_next_run ON schedules(next_run)")
            conn.commit()

    def _dict_factory(self, cursor, row):
        """Convert sqlite3 row to dictionary"""
        fields = [column[0] for column in cursor.description]
        return dict(zip(fields, row))

    def create_schedule(self, list_address: str, list_name: str, action: str,
                       schedule_type: str, time_str: str, days: Optional[list] = None,
                       timezone: str = 'UTC') -> int:
        """Create a new schedule and return its ID"""
        with sqlite3.connect(self.db_path) as conn:
            days_json = json.dumps(days) if days else None
            next_run = self._calculate_next_run(schedule_type, time_str, days, timezone)

            cursor = conn.execute("""
                INSERT INTO schedules
                (list_address, list_name, action, schedule_type, time, days, timezone, next_run)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (list_address, list_name, action, schedule_type, time_str, days_json, timezone, next_run))
            conn.commit()
            return cursor.lastrowid

    def get_all_schedules(self) -> list:
        """Get all schedules"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = self._dict_factory
            cursor = conn.execute("SELECT * FROM schedules ORDER BY created_at DESC")
            return cursor.fetchall()

    def get_schedules_by_list(self, list_address: str) -> list:
        """Get all schedules for a specific list"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = self._dict_factory
            cursor = conn.execute(
                "SELECT * FROM schedules WHERE list_address = ? ORDER BY time",
                (list_address,)
            )
            return cursor.fetchall()

    def get_schedule(self, schedule_id: int) -> Optional[dict]:
        """Get a single schedule by ID"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = self._dict_factory
            cursor = conn.execute("SELECT * FROM schedules WHERE id = ?", (schedule_id,))
            return cursor.fetchone()

    def update_schedule(self, schedule_id: int, **kwargs):
        """Update schedule fields"""
        if not kwargs:
            return

        # Build UPDATE query dynamically
        fields = []
        values = []
        for key, value in kwargs.items():
            if key == 'days' and isinstance(value, list):
                value = json.dumps(value)
            fields.append(f"{key} = ?")
            values.append(value)

        fields.append("updated_at = CURRENT_TIMESTAMP")
        values.append(schedule_id)

        query = f"UPDATE schedules SET {', '.join(fields)} WHERE id = ?"

        with sqlite3.connect(self.db_path) as conn:
            conn.execute(query, values)
            conn.commit()

    def delete_schedule(self, schedule_id: int):
        """Delete a schedule"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM schedules WHERE id = ?", (schedule_id,))
            conn.commit()

    def update_execution_status(self, schedule_id: int, status: str, error: Optional[str] = None):
        """Update schedule execution status"""
        now = datetime.now(pytz.UTC).isoformat()

        # Recalculate next run for all schedules (all are recurring now)
        schedule = self.get_schedule(schedule_id)
        if schedule:
            next_run = self._calculate_next_run(
                schedule['schedule_type'],
                schedule['time'],
                json.loads(schedule['days']) if schedule['days'] else None,
                schedule['timezone']
            )
        else:
            next_run = None

        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                UPDATE schedules
                SET last_run = ?, last_status = ?, last_error = ?, next_run = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (now, status, error, next_run, schedule_id))
            conn.commit()

    def get_enabled_schedules(self) -> list:
        """Get all enabled schedules"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = self._dict_factory
            cursor = conn.execute("SELECT * FROM schedules WHERE enabled = 1")
            return cursor.fetchall()

    def _calculate_next_run(self, schedule_type: str, time_str: str,
                           days: Optional[list], timezone_str: str) -> str:
        """Calculate the next run time for a schedule"""
        try:
            tz = pytz.timezone(timezone_str)
        except:
            tz = pytz.UTC

        # Parse time
        hour, minute = map(int, time_str.split(':'))

        # Get current time in the schedule's timezone
        now = datetime.now(tz)

        # Create a naive datetime for today at the scheduled time
        next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)

        # If the time has already passed today, start from tomorrow
        if next_run <= now:
            next_run += timedelta(days=1)

        # For weekly schedules, find the next matching day
        if schedule_type == 'weekly' and days:
            day_map = {'mon': 0, 'tue': 1, 'wed': 2, 'thu': 3, 'fri': 4, 'sat': 5, 'sun': 6}
            target_days = [day_map[d] for d in days if d in day_map]

            # Find next matching day
            max_tries = 7
            while max_tries > 0:
                if next_run.weekday() in target_days:
                    break
                next_run += timedelta(days=1)
                max_tries -= 1

        # For weekdays, ensure it's Monday-Friday
        elif schedule_type == 'weekdays':
            while next_run.weekday() >= 5:  # Saturday or Sunday
                next_run += timedelta(days=1)

        # For weekend, ensure it's Saturday or Sunday
        elif schedule_type == 'weekend':
            while next_run.weekday() < 5:  # Monday-Friday
                next_run += timedelta(days=1)

        # Return ISO format timestamp
        return next_run.isoformat()
