#!/usr/bin/env python3
"""
TelaWeb Wi-Fi Watchdog
Monitors Wi-Fi connectivity after initial provisioning.
Activates BLE advertising when Wi-Fi is down beyond a configurable threshold.
Continues Wi-Fi recovery in the background while BLE is active.
Disables BLE automatically once Wi-Fi is restored.
"""
import asyncio
import configparser
import json
import os
import signal
import subprocess
import sys
import time
from enum import Enum, auto
from typing import List, Dict

from dbus_next.aio import MessageBus
from dbus_next import Variant, BusType, Message
from dbus_next.service import ServiceInterface, method, dbus_property, PropertyAccess

# ---- Reuse from ble_wifi_config ----
from ble_wifi_config import (
    nm_active, current_ipv4, run, async_run, get_network_info, get_subnet_base,
    find_available_static_ip, wifi_scan_nm, wifi_scan_legacy,
    wifi_connect_nm, wifi_connect_legacy, get_default_adapter_path,
    Characteristic, Service, Advertisement, Application, PairingAgent,
    ScanResultsChar, SSIDChar, PasswordChar, StatusChar,
    build_object_tree, SERVICE_UUID, UUID, WLAN_IFACE, IP_WAIT_TIMEOUT_S,
    WIFI_OK_FLAG,
)

# ---- Config ----
CONFIG_PATH = '/etc/telaweb/watchdog.conf'
DEFAULTS = {
    'poll_interval_s': 15,
    'ble_threshold_s': 120,
    'recovery_interval_s': 30,
    'ping_target': '1.1.1.1',
    'ping_timeout_s': 5,
    'ble_local_name': 'Pi-Setup',
    'stability_window_s': 10,
}


def log(msg: str):
    print(f"[wifi-watchdog] {msg}", flush=True)


def load_config(path: str = CONFIG_PATH) -> dict:
    config = dict(DEFAULTS)
    if not os.path.exists(path):
        log(f"Config file {path} not found, using defaults")
        return config
    try:
        cp = configparser.ConfigParser()
        cp.read(path)
        if cp.has_section('watchdog'):
            for key in DEFAULTS:
                if cp.has_option('watchdog', key):
                    val = cp.get('watchdog', key)
                    if isinstance(DEFAULTS[key], int):
                        try:
                            config[key] = int(val)
                        except ValueError:
                            log(f"Invalid value for {key}: {val}, using default {DEFAULTS[key]}")
                    else:
                        config[key] = val
        log(f"Config loaded from {path}")
    except Exception as e:
        log(f"Error reading config: {e}, using defaults")
    return config


class WatchdogState(Enum):
    WIFI_OK = auto()
    WIFI_RECOVERING = auto()
    WIFI_DOWN_BLE_ON = auto()
    BLE_PROVISIONING = auto()


# ---- Watchdog BLE characteristic overrides ----

class WatchdogScanTriggerChar(Characteristic):
    """Scan trigger that uses the watchdog's own state."""
    def __init__(self, service_path, uuid, flags, watchdog):
        super().__init__(service_path, uuid, flags)
        self.watchdog = watchdog

    def on_write(self, data: bytes):
        if (data or b'').decode(errors='ignore').strip().lower() == 'start':
            asyncio.create_task(self.watchdog.do_wifi_scan())


class WatchdogConnectChar(Characteristic):
    """Connect characteristic that signals provisioning state to the watchdog."""
    def __init__(self, service_path, uuid, flags, watchdog):
        super().__init__(service_path, uuid, flags)
        self.watchdog = watchdog

    def on_write(self, data: bytes):
        if (data or b'').decode(errors='ignore').strip().lower() == 'apply':
            self.watchdog.provisioning_in_progress = True
            asyncio.create_task(self.watchdog.do_apply_and_connect())


class WifiWatchdog:
    def __init__(self, config: dict):
        self.config = config
        self.state = WatchdogState.WIFI_OK
        self.wifi_down_since = None
        self.ble_active = False
        self.provisioning_in_progress = False

        # BLE references (set when BLE starts)
        self.bus = None
        self.adapter_path = None
        self.scan_results_char = None
        self.status_char = None
        self.ble_state = {'ssid': '', 'password': '', 'status': 'idle', 'scan_results': []}

    def check_connectivity(self) -> bool:
        """Check Wi-Fi connectivity.
        Primary: wlan0 has an IP address (WiFi is associated).
        Fallback: internet ping (only reached when interface has no IP).
        This prevents false positives when the internet is temporarily
        unreachable but the device is correctly connected to the AP.
        """
        if self.check_wifi_interface():
            return True
        try:
            result = subprocess.run(
                ['ping', '-c', '1', '-W', str(self.config['ping_timeout_s']),
                 self.config['ping_target']],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                timeout=self.config['ping_timeout_s'] + 2
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, Exception):
            return False

    def check_wifi_interface(self) -> bool:
        """Check if wlan0 has an IP address."""
        return bool(current_ipv4())

    async def attempt_wifi_recovery(self) -> bool:
        """Attempt to reconnect using stored NetworkManager connection profile."""
        log("Attempting Wi-Fi recovery...")
        try:
            if nm_active():
                # Get the stored Wi-Fi connection name (async to avoid blocking event loop)
                result = await async_run("nmcli -t -f NAME,TYPE connection show | grep ':802-11-wireless' | head -1 | cut -d: -f1")
                conn_name = result.stdout.strip()
                if conn_name:
                    log(f"Reactivating connection: {conn_name}")
                    r = await async_run(f'nmcli connection up "{conn_name}"')
                    if r.returncode == 0:
                        for _ in range(15):
                            if current_ipv4():
                                log(f"Wi-Fi recovery successful, IP: {current_ipv4()}")
                                return True
                            await asyncio.sleep(1)
                    else:
                        log(f"nmcli connection up failed: {r.stderr.strip()}")
                else:
                    log("No stored Wi-Fi connection found")
                return False
            else:
                # Legacy: wpa_supplicant
                log("Using legacy wpa_cli reconfigure")
                await async_run(f'wpa_cli -i {WLAN_IFACE} reconfigure')
                for _ in range(15):
                    if current_ipv4():
                        log(f"Wi-Fi recovery successful (legacy), IP: {current_ipv4()}")
                        return True
                    await asyncio.sleep(1)
                return False
        except Exception as e:
            log(f"Recovery error: {e}")
            return False

    # ---- BLE lifecycle ----

    async def start_ble(self):
        """Start BLE GATT server and advertising."""
        if self.ble_active:
            return

        try:
            self.adapter_path = get_default_adapter_path()
            log(f"BLE adapter path: {self.adapter_path}")

            self.bus = await MessageBus(bus_type=BusType.SYSTEM).connect()

            # Setup pairing
            await self._setup_pairing()

            # Build GATT service tree
            app_path = '/org/ble/app0'
            svc_path = app_path + '/svc0'

            service = Service(svc_path, SERVICE_UUID, True)
            scan_trigger = WatchdogScanTriggerChar(svc_path, UUID(1), ['write'], self)
            scan_results = ScanResultsChar(svc_path, UUID(2), ['read', 'notify'])
            ssid_char = SSIDChar(svc_path, UUID(3), ['write'])
            pass_char = PasswordChar(svc_path, UUID(4), ['write'])
            connect_char = WatchdogConnectChar(svc_path, UUID(5), ['write'], self)
            status = StatusChar(svc_path, UUID(6), ['read', 'notify'])

            # Seed initial values
            scan_results.set_value(json.dumps([]).encode())
            status.set_value(b'idle')

            # Export GATT objects on D-Bus
            self.bus.export(svc_path, service)
            self.bus.export(scan_trigger.path, scan_trigger)
            self.bus.export(scan_results.path, scan_results)
            self.bus.export(ssid_char.path, ssid_char)
            self.bus.export(pass_char.path, pass_char)
            self.bus.export(connect_char.path, connect_char)
            self.bus.export(status.path, status)

            # ObjectManager root
            om_tree = build_object_tree(app_path, svc_path, service,
                                        [scan_trigger, scan_results, ssid_char,
                                         pass_char, connect_char, status])
            app = Application(app_path, om_tree)
            self.bus.export(app_path, app)

            # Keep refs for notifications
            self.scan_results_char = scan_results
            self.status_char = status

            # Register with BlueZ
            await self.bus.call(Message(
                destination='org.bluez', path=self.adapter_path,
                interface='org.bluez.GattManager1',
                member='RegisterApplication',
                signature='oa{sv}', body=[app_path, {}]
            ))
            log("Registered GATT application")

            # Start advertising
            local_name = self.config['ble_local_name']
            adv = Advertisement('/org/ble/adv0', [SERVICE_UUID], local_name)
            self.bus.export('/org/ble/adv0', adv)
            await self.bus.call(Message(
                destination='org.bluez', path=self.adapter_path,
                interface='org.bluez.LEAdvertisingManager1',
                member='RegisterAdvertisement',
                signature='oa{sv}', body=['/org/ble/adv0', {}]
            ))
            log(f"BLE advertising started as '{local_name}'")

            self.ble_active = True

            # Wire up SSIDChar and PasswordChar to use our state
            # They already write to the module-level ble_wifi_config.state,
            # so we need to patch that reference
            import ble_wifi_config
            ble_wifi_config.state = self.ble_state
            ble_wifi_config.bus = self.bus
            ble_wifi_config.scan_results_char = self.scan_results_char
            ble_wifi_config.status_char = self.status_char
            ble_wifi_config.adapter_path = self.adapter_path

        except Exception as e:
            log(f"Failed to start BLE: {e}")
            self.ble_active = False

    async def stop_ble(self):
        """Stop BLE advertising, unregister GATT app, and clean up."""
        if not self.ble_active:
            return

        try:
            await self.bus.call(Message(
                destination='org.bluez', path=self.adapter_path,
                interface='org.bluez.LEAdvertisingManager1',
                member='UnregisterAdvertisement',
                signature='o', body=['/org/ble/adv0']
            ))
            log("BLE advertising stopped")
        except Exception as e:
            log(f"Error stopping BLE advertisement: {e}")

        try:
            await self.bus.call(Message(
                destination='org.bluez', path=self.adapter_path,
                interface='org.bluez.GattManager1',
                member='UnregisterApplication',
                signature='o', body=['/org/ble/app0']
            ))
            log("GATT application unregistered")
        except Exception as e:
            log(f"Error unregistering GATT application: {e}")

        try:
            if self.bus:
                self.bus.disconnect()
                self.bus = None
        except Exception as e:
            log(f"Error disconnecting D-Bus: {e}")

        self.ble_active = False
        self.scan_results_char = None
        self.status_char = None
        log("BLE fully deactivated")

    async def _setup_pairing(self):
        """Register pairing agent and clear old pairings."""
        try:
            # Clear old pairings
            reply = await self.bus.call(Message(
                destination='org.bluez', path='/',
                interface='org.freedesktop.DBus.ObjectManager',
                member='GetManagedObjects', signature='', body=[]
            ))
            objects = reply.body[0]
            for path in objects:
                if '/dev_' in str(path) and str(path).startswith(str(self.adapter_path)):
                    try:
                        await self.bus.call(Message(
                            destination='org.bluez', path=self.adapter_path,
                            interface='org.bluez.Adapter1',
                            member='RemoveDevice',
                            signature='o', body=[path]
                        ))
                    except Exception:
                        pass

            # Register agent
            agent = PairingAgent()
            self.bus.export(agent.path, agent)

            # Make adapter pairable
            await self.bus.call(Message(
                destination='org.bluez', path=self.adapter_path,
                interface='org.freedesktop.DBus.Properties',
                member='Set', signature='ssv',
                body=['org.bluez.Adapter1', 'Pairable', Variant('b', True)]
            ))
            await self.bus.call(Message(
                destination='org.bluez', path=self.adapter_path,
                interface='org.freedesktop.DBus.Properties',
                member='Set', signature='ssv',
                body=['org.bluez.Adapter1', 'PairableTimeout', Variant('u', 0)]
            ))

            # Register with AgentManager
            await self.bus.call(Message(
                destination='org.bluez', path='/org/bluez',
                interface='org.bluez.AgentManager1',
                member='RegisterAgent',
                signature='os', body=[agent.path, 'NoInputNoOutput']
            ))
            await self.bus.call(Message(
                destination='org.bluez', path='/org/bluez',
                interface='org.bluez.AgentManager1',
                member='RequestDefaultAgent',
                signature='o', body=[agent.path]
            ))
            log("Pairing agent registered")
        except Exception as e:
            log(f"Pairing setup warning: {e}")

    # ---- BLE provisioning operations ----

    async def _set_status(self, txt: str):
        self.ble_state['status'] = txt
        if self.status_char:
            self.status_char.set_value(txt.encode())
            self.status_char.notify(self.bus)
        log(f"BLE STATUS -> {txt}")

    async def _push_scan_results(self, lst: list):
        self.ble_state['scan_results'] = lst
        if self.scan_results_char:
            self.scan_results_char.set_value(json.dumps(lst).encode())
            self.scan_results_char.notify(self.bus)
        log(f"BLE SCAN_RESULTS -> {len(lst)} SSIDs")

    async def do_wifi_scan(self):
        await self._set_status('scanning')
        try:
            ssids = wifi_scan_nm() if nm_active() else wifi_scan_legacy()
        except Exception as e:
            log(f"Scan error: {e}")
            ssids = []
        await self._push_scan_results(ssids)
        await self._set_status('idle')

    async def do_apply_and_connect(self):
        ssid = self.ble_state.get('ssid', '')
        psk = self.ble_state.get('password', '')
        if not ssid:
            await self._set_status('failed')
            self.provisioning_in_progress = False
            return

        await self._set_status('applying')
        ok = wifi_connect_nm(ssid, psk) if nm_active() else wifi_connect_legacy(ssid, psk)
        self.ble_state['password'] = ''  # clear ASAP

        if not ok:
            await self._set_status('failed')
            self.provisioning_in_progress = False
            return

        for _ in range(IP_WAIT_TIMEOUT_S):
            ip_with_cidr = current_ipv4()
            if ip_with_cidr:
                # Update marker file
                os.makedirs(os.path.dirname(WIFI_OK_FLAG), exist_ok=True)
                with open(WIFI_OK_FLAG, 'w') as f:
                    f.write('ok')
                ip_address = ip_with_cidr.split('/')[0] if '/' in ip_with_cidr else ip_with_cidr
                await self._set_status(f'connected:{ip_address}')
                self.provisioning_in_progress = False
                return
            await asyncio.sleep(1)

        await self._set_status('failed')
        self.provisioning_in_progress = False

    # ---- Main watchdog loop ----

    async def run(self):
        """Main watchdog event loop."""
        log(f"Starting watchdog (state: {self.state.name})")
        log(f"Config: poll={self.config['poll_interval_s']}s, "
            f"ble_threshold={self.config['ble_threshold_s']}s, "
            f"recovery={self.config['recovery_interval_s']}s, "
            f"ping={self.config['ping_target']}")

        # Initial state detection
        if not self.check_connectivity():
            log("Wi-Fi not connected on startup")
            self.wifi_down_since = time.monotonic()
            self.state = WatchdogState.WIFI_RECOVERING
        else:
            log("Wi-Fi connected on startup")

        while True:
            try:
                if self.state == WatchdogState.WIFI_OK:
                    await self._handle_wifi_ok()
                elif self.state == WatchdogState.WIFI_RECOVERING:
                    await self._handle_wifi_recovering()
                elif self.state == WatchdogState.WIFI_DOWN_BLE_ON:
                    await self._handle_wifi_down_ble_on()
                elif self.state == WatchdogState.BLE_PROVISIONING:
                    await self._handle_ble_provisioning()
            except Exception as e:
                log(f"Error in watchdog loop: {e}")
                await asyncio.sleep(5)

    async def _handle_wifi_ok(self):
        await asyncio.sleep(self.config['poll_interval_s'])
        if not self.check_connectivity():
            self.wifi_down_since = time.monotonic()
            self.state = WatchdogState.WIFI_RECOVERING
            log("Wi-Fi lost, entering recovery state")

    async def _handle_wifi_recovering(self):
        elapsed = time.monotonic() - self.wifi_down_since

        # Check if threshold exceeded
        if elapsed >= self.config['ble_threshold_s']:
            log(f"Wi-Fi down for {elapsed:.0f}s (threshold: {self.config['ble_threshold_s']}s), activating BLE")
            await self.start_ble()
            if self.ble_active:
                self.state = WatchdogState.WIFI_DOWN_BLE_ON
            else:
                log("BLE failed to start, staying in recovery mode (will retry)")
            return

        # Attempt recovery
        recovered = await self.attempt_wifi_recovery()
        if recovered:
            # Stability check
            log(f"Wi-Fi appears recovered, waiting {self.config['stability_window_s']}s for stability...")
            await asyncio.sleep(self.config['stability_window_s'])
            if self.check_connectivity():
                self.wifi_down_since = None
                self.state = WatchdogState.WIFI_OK
                log("Wi-Fi confirmed stable, returning to OK state")
                return
            else:
                log("Wi-Fi not stable after recovery, continuing recovery attempts")

        await asyncio.sleep(self.config['recovery_interval_s'])

    async def _handle_wifi_down_ble_on(self):
        # Check if BLE provisioning started
        if self.provisioning_in_progress:
            self.state = WatchdogState.BLE_PROVISIONING
            log("BLE provisioning in progress, pausing auto-recovery")
            return

        # Attempt background recovery
        recovered = await self.attempt_wifi_recovery()
        if recovered:
            log(f"Wi-Fi appears recovered, waiting {self.config['stability_window_s']}s for stability...")
            await asyncio.sleep(self.config['stability_window_s'])
            if self.check_connectivity():
                await self.stop_ble()
                self.wifi_down_since = None
                self.state = WatchdogState.WIFI_OK
                log("Wi-Fi recovered, BLE deactivated")
                return
            else:
                log("Wi-Fi not stable after recovery, BLE remains active")

        await asyncio.sleep(self.config['recovery_interval_s'])

    async def _handle_ble_provisioning(self):
        # Wait for provisioning to complete
        await asyncio.sleep(2)
        if not self.provisioning_in_progress:
            if self.check_connectivity():
                log("BLE provisioning succeeded, Wi-Fi connected")
                # Grace period for BLE client to read final status
                await asyncio.sleep(10)
                await self.stop_ble()
                self.wifi_down_since = None
                self.state = WatchdogState.WIFI_OK
            else:
                log("BLE provisioning finished but Wi-Fi not connected, resuming recovery")
                self.state = WatchdogState.WIFI_DOWN_BLE_ON


async def main():
    config = load_config()
    watchdog = WifiWatchdog(config)

    # Graceful shutdown on SIGTERM/SIGINT — clean up BLE resources
    def _request_shutdown(sig, frame):
        log(f"Received signal {sig}, scheduling shutdown...")
        asyncio.get_event_loop().create_task(_shutdown(watchdog))

    async def _shutdown(wd):
        log("Shutting down gracefully...")
        await wd.stop_ble()
        log("Shutdown complete")
        sys.exit(0)

    signal.signal(signal.SIGTERM, _request_shutdown)
    signal.signal(signal.SIGINT, _request_shutdown)

    await watchdog.run()


if __name__ == '__main__':
    asyncio.run(main())
