# Pi-hole Companion

A modern, feature-rich web interface for managing Pi-hole DNS ad-blocker with enhanced functionality including scheduling, advanced domain management, and comprehensive statistics visualization.

![Dashboard](https://img.shields.io/badge/Python-3.11+-blue.svg)
![Flask](https://img.shields.io/badge/Flask-3.0+-green.svg)
![Pi-hole](https://img.shields.io/badge/Pi--hole-v5%20%7C%20v6-red.svg)

## Features

### Dashboard
- **Real-time Statistics**: View total queries, blocked queries, blocking percentage, domains in lists, and active clients
- **24-Hour Trend Mini Chart**: Compact dual-line graph showing total vs blocked queries over 24 hours with smooth curves
- **Top Statistics**: Track top 5 queried domains, blocked domains, and active clients
- **Global Controls**: Enable/disable DNS blocking with optional timer
- **Dark Theme**: Modern, eye-friendly interface optimized for 24/7 monitoring

### List Management
- View all subscribed blocklists and allowlists
- Add new list subscriptions by URL
- Enable/disable individual lists
- Delete list subscriptions
- **Scheduling**: Automate list enable/disable actions

### Domain Management
- View and manage allow/deny domain rules
- Add domains to allowlist or denylist
- Automatic regex pattern conversion for simplified entry
- Enable/disable individual domain rules
- Support for both exact matches and regex patterns
- Delete domain rules

### Advanced Scheduling
- **Daily Schedules**: Run tasks every day at specified time
- **Weekday/Weekend**: Separate schedules for work days vs weekends
- **Custom Weekly**: Select specific days of the week
- **Timezone Support**: Automatic timezone detection and handling
- **Persistent Storage**: SQLite database for schedule management
- **Enable/Disable**: Temporarily disable schedules without deletion

## Screenshots

### Dashboard with 6 Stat Cards
The dashboard displays a modern grid of statistics cards:
- **Total Queries** (cyan) - Total DNS queries processed
- **Queries Blocked** (red) - Number of blocked queries
- **Blocked Percentage** (orange) - Percentage of queries blocked
- **Domains in Lists** (green) - Total domains in blocklists
- **Active Clients** (purple) - Number of active clients
- **24 Hour Trend** (blue) - Mini line chart showing total (cyan line) and blocked (red line) queries over 24 hours with smooth curve visualization

## Architecture

### Three-Layer Design

```
┌─────────────────────────────────────────┐
│        Presentation Layer               │
│  (Jinja2 Templates + CSS + Chart.js)   │
└─────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│        Application Layer                │
│     (Flask Routes + Business Logic)     │
└─────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│           API Layer                     │
│  (Pi-hole API Wrapper with v5/v6 support)│
└─────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│           Pi-hole Server                │
│      (DNS + FTL + Web Interface)        │
└─────────────────────────────────────────┘
```

## Installation

### Prerequisites
- Python 3.11 or higher
- Pi-hole v5 or v6 installed and running
- Pi-hole API password

### Setup Steps

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd pihole_companion
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Create environment configuration**:
   ```bash
   # Create .env file
   echo PIHOLE_BASE_URL=http://pi.hole > .env
   echo PIHOLE_PASSWORD=your_pihole_password >> .env
   echo FLASK_SECRET=your_secret_key_here >> .env
   echo HOST=0.0.0.0 >> .env
   echo PORT=8088 >> .env
   ```

4. **Create data directory**:
   ```bash
   mkdir data
   ```

5. **Run the application**:
   ```bash
   python app.py
   ```

6. **Access the interface**:
   Open your browser to `http://localhost:8088`

## Local Testing Quick Start

These notes are here to help future local test runs start quickly and consistently.

### Standard local run

From the repository root:

```bash
pip install -r requirements.txt
python app.py
```

When startup succeeds, Flask should report:

- `Running on http://127.0.0.1:8088`
- `Running on http://<your-lan-ip>:8088`

The app can then be checked at `http://127.0.0.1:8088`.

### Important behavior during testing

- The app loads `.env` automatically via `python-dotenv`.
- Missing or unreachable Pi-hole data does not usually stop Flask from booting; most Pi-hole errors surface when routes are requested.
- Scheduler startup logs are expected during boot.

### If you are an agent running inside a sandbox

Foreground startup is the most reliable verification step:

```bash
python app.py
```

If the app starts in the foreground but a detached/background process exits immediately, the sandbox is likely reaping child processes. In that case, start the app outside the sandbox so it can stay alive for browser-based testing, then verify with:

```bash
curl http://127.0.0.1:8088
```

or on PowerShell:

```powershell
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:8088
```

### Log files used in local testing

If you launch the app with redirected output, keep logs here:

- `.playwright-mcp/server.out.log`
- `.playwright-mcp/server.err.log`

## Configuration

### Environment Variables

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `PIHOLE_BASE_URL` | Pi-hole server URL | `http://pi.hole` | Yes |
| `PIHOLE_PASSWORD` | Pi-hole API password | - | Yes |
| `FLASK_SECRET` | Flask session secret key | `dev` | Recommended |
| `HOST` | Flask bind address | `0.0.0.0` | No |
| `PORT` | Flask bind port | `8088` | No |

### Finding Your Pi-hole Password

1. **Via Web Interface**: Settings → API/Web interface → Show API token
2. **Via Command Line**: `sudo cat /etc/pihole/setupVars.conf | grep WEBPASSWORD`
3. **Set New Password**: `pihole -a -p`

## Project Structure

```
pihole_companion/
├── app.py                      # Flask application and routes
├── pihole_api.py              # Pi-hole API client wrapper
├── scheduler.py               # APScheduler task management
├── schedules_db.py            # SQLite database operations
├── cli_task.py                # Command-line task execution
├── requirements.txt           # Python dependencies
├── .env                       # Configuration (not in git)
├── README.md                  # This file
├── data/
│   └── schedules.db          # SQLite database (auto-created)
├── static/
│   └── styles.css            # Global CSS styling
└── templates/
    ├── base.html             # Base template layout
    ├── dashboard.html        # Dashboard view
    ├── lists.html            # Lists management
    └── domains.html          # Domain management
```

## API Support

### Pi-hole Version Compatibility

This application supports both Pi-hole v5 and v6:

- **Automatic Detection**: Probes for v6 endpoints at startup
- **Graceful Fallback**: Falls back to v5 PHP API when v6 unavailable
- **Dual Implementation**: All features work on both versions

### v6 Features (Preferred)
- REST API with session authentication
- Enhanced domain management
- Improved list subscriptions
- Database summary statistics

### v5 Fallback
- PHP-based API with password authentication
- Core functionality maintained
- Some advanced features unavailable

## Technology Stack

### Backend
- **Flask 3.0.3** - Web framework
- **requests 2.32.3** - HTTP client
- **APScheduler 3.10.4** - Task scheduling
- **SQLite** - Schedule persistence
- **tzlocal** - Timezone detection

### Frontend
- **Jinja2** - Template engine
- **Chart.js 4.4.1** - Data visualization
- **Custom CSS** - Dark theme design
- **Google Fonts (Inter)** - Typography

## Development

### Adding New Features

1. **Add API Method** ([pihole_api.py](pihole_api.py)):
   ```python
   def new_feature(self):
       if self.v6:
           self._auth_v6()
           r = requests.get(f"{self.base_url}/api/endpoint",
                          headers=self._headers_v6(),
                          timeout=self.timeout)
           r.raise_for_status()
           return r.json()
       else:
           # v5 fallback
           return fallback_data
   ```

2. **Create Flask Route** ([app.py](app.py)):
   ```python
   @app.route("/feature")
   def feature_view():
       try:
           data = api.new_feature()
           return render_template("feature.html", data=data)
       except Exception as e:
           flash(f"Error: {e}", "error")
           return render_template("feature.html", data=None)
   ```

3. **Build Template** ([templates/feature.html](templates/)):
   ```html
   {% extends "base.html" %}
   {% block content %}
     <!-- Your feature UI here -->
   {% endblock %}
   ```

### Color Palette

The dark theme uses consistent color coding:

```css
--bg: #0b1020        /* Background */
--panel: #111833     /* Panels */
--text: #eaf0ff      /* Text */
--muted: #a7b0c9     /* Muted text */
--ok: #2ecc71        /* Success/green */
--warn: #ffb020      /* Warning/orange */
--err: #ff5c7a       /* Error/red */
```

**Stat Card Colors**:
- Cyan (`#17a2b8`) - Total Queries
- Red (`#e74c3c`) - Queries Blocked
- Orange (`#f39c12`) - Blocked Percentage
- Green (`#00bc8c`) - Domains in Lists
- Purple (`#9b59b6`) - Active Clients
- Blue (`#3498db`) - 24 Hour Trend

**Mini Chart Colors** (24 Hour Trend):
- Bright Cyan (`#00d4ff`) - Total queries line (3px thick, no fill)
- Red (`#e74c3c`) - Blocked queries line (2px thick, 20% opacity fill)

## Troubleshooting

### Connection Issues

**Problem**: Cannot connect to Pi-hole server

**Solutions**:
- Verify `PIHOLE_BASE_URL` in `.env` matches your Pi-hole address
- Test Pi-hole connectivity: `curl http://pi.hole/admin`
- Check Pi-hole is running: `pihole status`
- Verify firewall allows connection to Pi-hole port

### Authentication Errors

**Problem**: "Failed to authenticate to Pi-hole v6 API"

**Solutions**:
- Confirm `PIHOLE_PASSWORD` in `.env` is correct
- Check Pi-hole web password: Settings → API/Web interface
- Reset password: `pihole -a -p`
- Test manually: `curl -X POST http://pi.hole/api/auth -d '{"password":"YOUR_PASSWORD"}'`

### Missing Dashboard Data

**Problem**: Cards show "—" instead of numbers

**Debug Steps**:
1. Check Flask console for error messages
2. Verify Pi-hole FTL is running: `pihole status`
3. Test API endpoint manually: `curl http://pi.hole/api/stats/summary`
4. Check browser console for JavaScript errors

### Schedule Not Running

**Problem**: Scheduled task doesn't execute

**Solutions**:
- Verify schedule is enabled (toggle in UI)
- Check system time and timezone are correct
- Review Flask console for scheduler logs
- Confirm APScheduler is running (logged at startup)

## Contributing

Contributions are welcome! Please follow these guidelines:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Code Style
- Follow PEP 8 for Python code
- Use meaningful variable names
- Add docstrings to functions
- Maintain consistent error handling patterns

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- **Pi-hole Team** - For the amazing DNS ad-blocking solution
- **Flask Team** - For the excellent web framework
- **Chart.js** - For beautiful data visualizations
- **APScheduler** - For reliable task scheduling

## Support

For issues, questions, or feature requests:
- Check existing issues on GitHub
- Review Pi-hole documentation: https://docs.pi-hole.net/
- Flask documentation: https://flask.palletsprojects.com/

## Roadmap

Future enhancements under consideration:

- [ ] Query log viewer with filtering
- [ ] Client grouping and management
- [ ] Custom blocklist editor
- [ ] Backup/restore configuration
- [ ] Multi-Pi-hole support
- [ ] Real-time updates via WebSockets
- [ ] Mobile app integration
- [ ] Email notifications for events
- [ ] Advanced analytics and reporting

---

**Version**: 1.1.0
**Last Updated**: 2026-01-06
**Maintainer**: Your Name

Made with ❤️ for the Pi-hole community
