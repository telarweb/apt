#!/usr/bin/env python3
# BLE Wi-Fi provisioning using BlueZ D-Bus directly (dbus-next)
# Requires: bluetoothd -E, dbus-next, NetworkManager preferred
import asyncio, json, os, re, subprocess, time, sys
from typing import List, Dict

from dbus_next.aio import MessageBus
from dbus_next import Variant, BusType, Message
from dbus_next.service import ServiceInterface, method, dbus_property, PropertyAccess

# ---- Config ----
SERVICE_UUID = '12345678-1234-5678-1234-56789abc0000'
UUID = lambda n: f'12345678-1234-5678-1234-56789abc00{n:02d}'

LOCAL_NAME = 'Pi-Setup'
WIFI_OK_FLAG = '/opt/wifi-provision/.wifi_configured'
WLAN_IFACE = 'wlan0'
IP_WAIT_TIMEOUT_S = 25
# ---------------

state = {'ssid': '', 'password': '', 'status': 'idle', 'scan_results': []}

def log(msg: str):
    print(f"[ble-provision] {msg}", flush=True)

def run(cmd: str):
    return subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

def nm_active() -> bool:
    return subprocess.run("systemctl is-active --quiet NetworkManager", shell=True).returncode == 0

def current_ipv4() -> str:
    return run(f"ip -o -4 addr show {WLAN_IFACE} | awk '{{print $4}}'").stdout.strip()

def get_network_info() -> dict:
    """Get current network info (gateway, DNS, subnet) from DHCP-assigned connection"""
    info = {'gateway': None, 'dns': None, 'prefix': 24}

    # Get gateway from ip route
    gw_out = run("ip route show default | awk '/default/ {print $3}'").stdout.strip()
    if gw_out:
        info['gateway'] = gw_out.split('\n')[0]

    # Get DNS from NetworkManager
    dns_out = run(f"nmcli -t -f IP4.DNS device show {WLAN_IFACE} | head -1 | cut -d: -f2").stdout.strip()
    if dns_out:
        info['dns'] = dns_out
    else:
        info['dns'] = info.get('gateway', '8.8.8.8')  # Fallback to gateway or Google DNS

    return info

def get_subnet_base(gateway: str) -> str:
    """Extract subnet base from gateway (e.g., 192.168.1.1 -> 192.168.1)"""
    parts = gateway.split('.')
    if len(parts) == 4:
        return '.'.join(parts[:3])
    return '192.168.1'  # Fallback

def find_available_static_ip(subnet_base: str, start: int = 7) -> str:
    """Find an available IP starting from subnet.start (e.g., 192.168.1.7)"""
    for i in range(start, 50):  # Check .7 through .49
        candidate = f"{subnet_base}.{i}"
        # Ping with 1 second timeout, 1 packet
        result = run(f"ping -c 1 -W 1 {candidate}")
        if result.returncode != 0:  # No response = IP is available
            log(f"Static IP candidate {candidate} is available")
            return candidate
        log(f"Static IP candidate {candidate} is in use, trying next")
    return f"{subnet_base}.{start}"  # Fallback to .7 if all responded

def wifi_scan_nm() -> List[str]:
    run(f"nmcli dev set {WLAN_IFACE} managed yes")
    run(f"nmcli dev wifi rescan ifname {WLAN_IFACE}")
    out = run(f"nmcli -t -f SSID dev wifi list ifname {WLAN_IFACE}").stdout
    seen, res = set(), []
    for line in out.splitlines():
        s = line.strip()
        if s and s not in seen:
            seen.add(s); res.append(s)
    return res

def wifi_connect_nm(ssid: str, psk: str) -> bool:
    # First, check if already connected to this SSID
    current = run(f"nmcli -t -f NAME,DEVICE connection show --active | grep {WLAN_IFACE}").stdout.strip()
    if current and ssid in current:
        log(f"Already connected to {ssid}")
        return True

    # Delete any existing connection profile for this SSID to avoid conflicts
    run(f'nmcli connection delete "{ssid}" 2>/dev/null')

    if psk:
        # Step 1: Create connection with DHCP first to get network info
        cmd = f'nmcli connection add type wifi ifname {WLAN_IFACE} con-name "{ssid}" ssid "{ssid}" wifi-sec.key-mgmt wpa-psk wifi-sec.psk "{psk}" ipv4.method auto'
        r = run(cmd)
        if r.returncode != 0:
            log(f"nmcli connection add failed: {r.stderr}")
            return False

        # Activate to get DHCP info
        r = run(f'nmcli connection up "{ssid}"')
        if r.returncode != 0:
            log(f"nmcli connection up failed: {r.stderr}")
            return False

        # Wait for DHCP to assign IP
        log("Waiting for DHCP to assign IP...")
        time.sleep(3)

        # Step 2: Get network info and find static IP
        net_info = get_network_info()
        if net_info['gateway']:
            subnet_base = get_subnet_base(net_info['gateway'])
            static_ip = find_available_static_ip(subnet_base)

            log(f"Configuring static IP: {static_ip}, gateway: {net_info['gateway']}, dns: {net_info['dns']}")

            # Step 3: Modify connection to use static IP
            run(f'nmcli connection modify "{ssid}" ipv4.method manual ipv4.address "{static_ip}/24" ipv4.gateway "{net_info["gateway"]}" ipv4.dns "{net_info["dns"]}"')

            # Restart connection to apply static IP
            run(f'nmcli connection down "{ssid}"')
            time.sleep(1)
            r = run(f'nmcli connection up "{ssid}"')
            if r.returncode != 0:
                log(f"Failed to apply static IP, reverting to DHCP: {r.stderr}")
                run(f'nmcli connection modify "{ssid}" ipv4.method auto')
                run(f'nmcli connection up "{ssid}"')
        else:
            log("Could not detect gateway, keeping DHCP configuration")

        return True
    else:
        # Open network (no password) - keep simple DHCP
        cmd = f'nmcli dev wifi connect "{ssid}" ifname {WLAN_IFACE}'
        r = run(cmd)
        if r.returncode != 0:
            log(f"nmcli connect failed: {r.stderr}")
        return r.returncode == 0

def wifi_scan_legacy() -> List[str]:
    out = run(f"iw dev {WLAN_IFACE} scan | grep 'SSID:' | sed 's/^\\s*SSID: \\(.*\\)$/\\1/'").stdout
    seen, res = set(), []
    for line in out.splitlines():
        s = line.strip()
        if s and s not in seen:
            seen.add(s); res.append(s)
    return res

def wifi_connect_legacy(ssid: str, psk: str) -> bool:
    if run("command -v wpa_cli").returncode != 0:
        return False
    add = run(f'wpa_cli -i {WLAN_IFACE} add_network').stdout.strip()
    if not re.match(r'^\d+$', add or ''):
        return False
    net_id = add
    run(f'wpa_cli -i {WLAN_IFACE} set_network {net_id} ssid \'"{ssid}"\'')
    if psk:
        run(f'wpa_cli -i {WLAN_IFACE} set_network {net_id} psk \'"{psk}"\'')
        run(f'wpa_cli -i {WLAN_IFACE} set_network {net_id} key_mgmt WPA-PSK')
    else:
        run(f'wpa_cli -i {WLAN_IFACE} set_network {net_id} key_mgmt NONE')
    run(f'wpa_cli -i {WLAN_IFACE} enable_network {net_id}')
    run(f'wpa_cli -i {WLAN_IFACE} save_config')
    run(f'wpa_cli -i {WLAN_IFACE} reconfigure')
    return True

def get_default_adapter_path() -> str:
    out = run("dbus-send --system --dest=org.bluez --print-reply / org.freedesktop.DBus.ObjectManager.GetManagedObjects | awk '/bluez\\/hci/{print $3; exit}'").stdout.strip()
    out = out.strip().strip('"').strip("'")
    if out.startswith('/org/bluez/hci'):
        return out
    out = run("busctl --system tree org.bluez | awk '/\\/org\\/bluez\\/hci[0-9]+$/{print $1; exit}'").stdout.strip()
    out = out.strip().strip('"').strip("'")
    if out.startswith('/org/bluez/hci'):
        return out
    return "/org/bluez/hci0"

# ---- BlueZ GATT/Adv minimal classes ----
class Characteristic(ServiceInterface):
    def __init__(self, service_path, uuid, flags):
        self.path = service_path + '/char_' + uuid.replace('-', '')
        super().__init__('org.bluez.GattCharacteristic1')
        self.uuid = uuid
        self.service = service_path
        self.flags = flags
        self._value = b''
        self._notify_subs = 0

    @dbus_property(access=PropertyAccess.READ)
    def UUID(self) -> 's':
        return self.uuid

    @dbus_property(access=PropertyAccess.READ)
    def Service(self) -> 'o':
        return self.service

    @dbus_property(access=PropertyAccess.READ)
    def Flags(self) -> 'as':
        return self.flags

    @method()
    def ReadValue(self, options: 'a{sv}') -> 'ay':
        return self._value

    @method()
    def WriteValue(self, value: 'ay', options: 'a{sv}'):
        self.on_write(bytes(value))

    @method()
    def StartNotify(self):
        self._notify_subs += 1
        log(f"StartNotify called on {self.uuid}, subs={self._notify_subs}")

    @method()
    def StopNotify(self):
        self._notify_subs = max(0, self._notify_subs - 1)
        log(f"StopNotify called on {self.uuid}, subs={self._notify_subs}")

    def set_value(self, val: bytes):
        self._value = val

    def notify(self, bus: MessageBus):
        if self._notify_subs <= 0:
            log(f"notify() called on {self.uuid} but no subscribers (subs={self._notify_subs})")
            return
        props = {'Value': Variant('ay', self._value)}
        msg = Message(destination='org.bluez',
                      path=self.path,
                      interface='org.freedesktop.DBus.Properties',
                      member='PropertiesChanged',
                      signature='sa{sv}as',
                      body=['org.bluez.GattCharacteristic1', props, []])
        asyncio.create_task(bus.call(msg))
        log(f"notify() sent for {self.uuid}, value={self._value[:50]}")

    def on_write(self, data: bytes):
        pass

class Service(ServiceInterface):
    def __init__(self, path, uuid, primary=True):
        super().__init__('org.bluez.GattService1')
        self.path = path
        self.uuid = uuid
        self.primary = primary

    @dbus_property(access=PropertyAccess.READ)
    def UUID(self) -> 's':
        return self.uuid

    @dbus_property(access=PropertyAccess.READ)
    def Primary(self) -> 'b':
        return self.primary

class Advertisement(ServiceInterface):
    def __init__(self, path, service_uuids, local_name):
        super().__init__('org.bluez.LEAdvertisement1')
        self.path = path
        self.service_uuids = service_uuids
        self.local_name = local_name

    @dbus_property(access=PropertyAccess.READ)
    def Type(self) -> 's':
        return 'peripheral'

    @dbus_property(access=PropertyAccess.READ)
    def ServiceUUIDs(self) -> 'as':
        return self.service_uuids

    @dbus_property(access=PropertyAccess.READ)
    def LocalName(self) -> 's':
        return self.local_name

    @dbus_property(access=PropertyAccess.READ)
    def Includes(self) -> 'as':
        return []

    @method()
    def Release(self):
        pass

# Application root implementing ObjectManager (REQUIRED by BlueZ)
class Application(ServiceInterface):
    def __init__(self, app_path: str, objects: Dict[str, Dict[str, Dict[str, Variant]]]):
        super().__init__('org.freedesktop.DBus.ObjectManager')
        self.path = app_path
        self.objects = objects  # mapping path -> { iface: {prop: Variant} }

    @method()
    def GetManagedObjects(self) -> 'a{oa{sa{sv}}}':
        return self.objects

# Characteristics for our flow
class ScanTriggerChar(Characteristic):
    def on_write(self, data: bytes):
        if (data or b'').decode(errors='ignore').strip().lower() == 'start':
            asyncio.create_task(do_wifi_scan())

class ScanResultsChar(Characteristic): pass
class SSIDChar(Characteristic):
    def on_write(self, data: bytes):
        state['ssid'] = (data or b'').decode(errors='ignore').strip()
class PasswordChar(Characteristic):
    def on_write(self, data: bytes):
        state['password'] = (data or b'').decode(errors='ignore')
class ConnectChar(Characteristic):
    def on_write(self, data: bytes):
        if (data or b'').decode(errors='ignore').strip().lower() == 'apply':
            asyncio.create_task(do_apply_and_connect())
class StatusChar(Characteristic): pass

# Globals filled in main()
bus: MessageBus = None
scan_results_char: ScanResultsChar = None
status_char: StatusChar = None
adapter_path = None

async def set_status(txt: str):
    state['status'] = txt
    status_char.set_value(txt.encode())
    status_char.notify(bus)
    log(f"STATUS -> {txt}")

async def push_scan_results(lst: List[str]):
    state['scan_results'] = lst
    scan_results_char.set_value(json.dumps(lst).encode())
    scan_results_char.notify(bus)
    log(f"SCAN_RESULTS -> {len(lst)} SSIDs")

async def do_wifi_scan():
    await set_status('scanning')
    try:
        ssids = wifi_scan_nm() if nm_active() else wifi_scan_legacy()
    except Exception as e:
        log(f"scan error: {e}")
        ssids = []
    await push_scan_results(ssids)
    await set_status('idle')

async def do_apply_and_connect():
    ssid = state.get('ssid','')
    psk  = state.get('password','')
    if not ssid:
        await set_status('failed'); return
    await set_status('applying')
    ok = wifi_connect_nm(ssid, psk) if nm_active() else wifi_connect_legacy(ssid, psk)
    state['password'] = ''  # clear ASAP
    if not ok:
        await set_status('failed'); return
    for _ in range(IP_WAIT_TIMEOUT_S):
        ip_with_cidr = current_ipv4()
        if ip_with_cidr:
            os.makedirs(os.path.dirname(WIFI_OK_FLAG), exist_ok=True)
            open(WIFI_OK_FLAG,'w').write('ok')
            # Extract IP address without CIDR notation (e.g., "192.168.1.100/24" -> "192.168.1.100")
            ip_address = ip_with_cidr.split('/')[0] if '/' in ip_with_cidr else ip_with_cidr
            await set_status(f'connected:{ip_address}')
            return
        await asyncio.sleep(1)
    await set_status('failed')

async def register_app(app_path: str):
    await bus.call(Message(
        destination='org.bluez',
        path=adapter_path,
        interface='org.bluez.GattManager1',
        member='RegisterApplication',
        signature='oa{sv}',
        body=[app_path, {}]
    ))
    log("Registered GATT application")

async def register_adv(adv_obj: Advertisement):
    bus.export('/org/ble/adv0', adv_obj)
    await bus.call(Message(
        destination='org.bluez',
        path=adapter_path,
        interface='org.bluez.LEAdvertisingManager1',
        member='RegisterAdvertisement',
        signature='oa{sv}',
        body=['/org/ble/adv0', {}]
    ))
    log("Registered advertisement")

async def unregister_adv():
    try:
        await bus.call(Message(
            destination='org.bluez',
            path=adapter_path,
            interface='org.bluez.LEAdvertisingManager1',
            member='UnregisterAdvertisement',
            signature='o',
            body=['/org/ble/adv0']
        ))
        log("Unregistered advertisement")
    except Exception as e:
        log(f"Unregister adv error: {e}")

async def stop_advertising():
    await unregister_adv()

def build_object_tree(app_path: str, svc_path: str, service: Service, chars: List[Characteristic]):
    """
    Build the a{oa{sa{sv}}} structure for ObjectManager.GetManagedObjects.
    Only static properties are required here.
    """
    om: Dict[str, Dict[str, Dict[str, Variant]]] = {}

    # Service object
    om[svc_path] = {
        'org.bluez.GattService1': {
            'UUID': Variant('s', service.uuid),
            'Primary': Variant('b', True),
            'Includes': Variant('ao', []),
        }
    }

    # Characteristics
    for ch in chars:
        om[ch.path] = {
            'org.bluez.GattCharacteristic1': {
                'UUID': Variant('s', ch.uuid),
                'Service': Variant('o', svc_path),
                'Flags': Variant('as', ch.flags),
            }
        }
    return om

class PairingAgent(ServiceInterface):
    """Simple pairing agent that auto-accepts all pairing requests"""
    def __init__(self):
        super().__init__('org.bluez.Agent1')
        self.path = '/org/ble/agent'

    @method()
    def Release(self):
        log("Pairing agent released")

    @method()
    def RequestPinCode(self, device: 'o') -> 's':
        log(f"RequestPinCode from {device}")
        return "0000"

    @method()
    def DisplayPinCode(self, device: 'o', pincode: 's'):
        log(f"DisplayPinCode: {pincode}")

    @method()
    def RequestPasskey(self, device: 'o') -> 'u':
        log(f"RequestPasskey from {device}")
        return 0

    @method()
    def DisplayPasskey(self, device: 'o', passkey: 'u', entered: 'q'):
        log(f"DisplayPasskey: {passkey}")

    @method()
    def RequestConfirmation(self, device: 'o', passkey: 'u'):
        log(f"RequestConfirmation: {passkey} - auto-accepting")
        # Auto-accept by returning without raising exception

    @method()
    def RequestAuthorization(self, device: 'o'):
        log(f"RequestAuthorization from {device} - auto-accepting")
        # Auto-accept by returning without raising exception

    @method()
    def AuthorizeService(self, device: 'o', uuid: 's'):
        log(f"AuthorizeService: {uuid} - auto-accepting")
        # Auto-accept by returning without raising exception

    @method()
    def Cancel(self):
        log("Pairing cancelled")

async def clear_old_pairings():
    """Remove all existing paired devices via D-Bus"""
    try:
        # Get list of managed objects to find devices
        reply = await bus.call(Message(
            destination='org.bluez',
            path='/',
            interface='org.freedesktop.DBus.ObjectManager',
            member='GetManagedObjects',
            signature='',
            body=[]
        ))

        objects = reply.body[0]
        for path in objects:
            if '/dev_' in str(path) and str(path).startswith(str(adapter_path)):
                try:
                    # Remove each device
                    await bus.call(Message(
                        destination='org.bluez',
                        path=adapter_path,
                        interface='org.bluez.Adapter1',
                        member='RemoveDevice',
                        signature='o',
                        body=[path]
                    ))
                    log(f"Removed device: {path}")
                except:
                    pass
    except Exception as e:
        log(f"Clear pairings warning: {e}")

async def setup_pairing():
    """Register a pairing agent that auto-accepts all pairing requests"""
    try:
        # Clear any old pairings first
        await clear_old_pairings()

        agent = PairingAgent()
        bus.export(agent.path, agent)

        # Make adapter pairable
        await bus.call(Message(
            destination='org.bluez',
            path=adapter_path,
            interface='org.freedesktop.DBus.Properties',
            member='Set',
            signature='ssv',
            body=['org.bluez.Adapter1', 'Pairable', Variant('b', True)]
        ))

        # Set pairable timeout to 0 (always pairable)
        await bus.call(Message(
            destination='org.bluez',
            path=adapter_path,
            interface='org.freedesktop.DBus.Properties',
            member='Set',
            signature='ssv',
            body=['org.bluez.Adapter1', 'PairableTimeout', Variant('u', 0)]
        ))

        # Register the agent with BlueZ
        await bus.call(Message(
            destination='org.bluez',
            path='/org/bluez',
            interface='org.bluez.AgentManager1',
            member='RegisterAgent',
            signature='os',
            body=[agent.path, 'NoInputNoOutput']
        ))

        # Set as default agent
        await bus.call(Message(
            destination='org.bluez',
            path='/org/bluez',
            interface='org.bluez.AgentManager1',
            member='RequestDefaultAgent',
            signature='o',
            body=[agent.path]
        ))

        log("Pairing agent registered and adapter set to pairable")
    except Exception as e:
        log(f"Pairing setup warning: {e}")

async def main():
    global bus, scan_results_char, status_char, adapter_path

    adapter_path = get_default_adapter_path()
    log(f"Adapter path: {adapter_path}")

    bus = await MessageBus(bus_type=BusType.SYSTEM).connect()

    # Setup pairing to prevent Android bonding timeout
    await setup_pairing()

    app_path = '/org/ble/app0'
    svc_path = app_path + '/svc0'

    service = Service(svc_path, SERVICE_UUID, True)
    scan_trigger = ScanTriggerChar(svc_path, UUID(1), ['write'])
    scan_results = ScanResultsChar(svc_path, UUID(2), ['read', 'notify'])
    ssid_char    = SSIDChar(svc_path, UUID(3), ['write'])
    pass_char    = PasswordChar(svc_path, UUID(4), ['write'])
    connect_char = ConnectChar(svc_path, UUID(5), ['write'])
    status       = StatusChar(svc_path, UUID(6), ['read', 'notify'])

    # seed initial values
    scan_results.set_value(json.dumps(state['scan_results']).encode())
    status.set_value(state['status'].encode())

    # export all GATT objects
    bus.export(svc_path, service)
    bus.export(scan_trigger.path, scan_trigger)
    bus.export(scan_results.path, scan_results)
    bus.export(ssid_char.path, ssid_char)
    bus.export(pass_char.path, pass_char)
    bus.export(connect_char.path, connect_char)
    bus.export(status.path, status)

    # ObjectManager root (REQUIRED)
    om_tree = build_object_tree(app_path, svc_path, service,
                                [scan_trigger, scan_results, ssid_char, pass_char, connect_char, status])
    app = Application(app_path, om_tree)
    bus.export(app_path, app)

    # keep refs for notify
    scan_results_char = scan_results
    status_char = status

    # register with BlueZ and advertise
    await register_app(app_path)
    await register_adv(Advertisement('/org/ble/adv0', [SERVICE_UUID], LOCAL_NAME))

    log("Provisioning active; advertising started (no timeout)")
    while True:
        await asyncio.sleep(1)
        if os.path.exists(WIFI_OK_FLAG):
            log("WiFi configured successfully, waiting 10 seconds before shutting down...")
            await asyncio.sleep(10)
            await stop_advertising()
            break
    log("Provisioning stopping (WiFi configured)")
    # keep process alive (optional) to allow readbacks; systemd will handle stop

if __name__ == '__main__':
    asyncio.run(main())
