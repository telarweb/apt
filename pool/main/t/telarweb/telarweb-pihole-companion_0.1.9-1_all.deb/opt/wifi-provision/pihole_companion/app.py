import os
import socket
import json
import atexit
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from dotenv import load_dotenv
from pihole_api import PiHoleAPI
from scheduler import ScheduleManager
from schedules_db import SchedulesDB
from i18n import load_translations, _, get_locale
import tzlocal

__version__ = "0.1.9"

load_dotenv()

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "dev")

load_translations()

def get_host_ip():
    """Get the local IP address of this host"""
    try:
        # Create a socket to determine the local IP
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "unknown"

@app.context_processor
def inject_globals():
    """Make host_ip, version, and i18n available to all templates"""
    return {
        'host_ip': get_host_ip(),
        'version': __version__,
        '_': _,
        'get_locale': get_locale,
        'js_translations': {
            'failed_toggle_schedule': _('js_failed_toggle_schedule'),
            'confirm_delete_schedule': _('js_confirm_delete_schedule'),
            'confirm_delete_domain': _('js_confirm_delete_domain'),
            'error_prefix': _('js_error_prefix'),
        }
    }


@app.template_filter('translate_days')
def translate_days_filter(days_str):
    day_map = {
        'mon': _('day_mon'), 'tue': _('day_tue'), 'wed': _('day_wed'),
        'thu': _('day_thu'), 'fri': _('day_fri'), 'sat': _('day_sat'),
        'sun': _('day_sun')
    }
    result = days_str.replace('[', '').replace(']', '').replace('"', '')
    for code, name in day_map.items():
        result = result.replace(code, name)
    return result


@app.template_filter('thousands')
def thousands_filter(value):
    """Format an integer with non-breaking thin spaces as thousands separators."""
    try:
        n = int(value)
    except (TypeError, ValueError):
        return value
    # Group digits and join with a non-breaking space so the number never wraps.
    return f"{n:,}".replace(",", " ")

BASE_URL = os.environ.get("PIHOLE_BASE_URL", "http://pi.hole")
PASSWORD = os.environ.get("PIHOLE_PASSWORD", "")
api = PiHoleAPI(BASE_URL, PASSWORD)

# Initialize scheduler
try:
    system_tz = tzlocal.get_localzone().key
except:
    system_tz = 'UTC'

schedules_db = SchedulesDB(os.path.join(os.getcwd(), "data", "schedules.db"))
schedule_manager = ScheduleManager(schedules_db, api, system_tz)
schedule_manager.start()

# Graceful shutdown
atexit.register(lambda: schedule_manager.stop())

@app.route("/")
def dashboard():
    try:
        s = api.summary()
        blocking = api.get_blocking()

        # Extract client counts from summary
        active_clients = s.get('active_clients', 0)
        total_clients = s.get('total_clients', 0)

        try:
            history = api.get_history()
        except Exception as e:
            print(f"Error fetching history: {e}")
            history = None

        return render_template("dashboard.html",
                             s=s,
                             blocking=blocking,
                             history=history,
                             active_clients=active_clients,
                             total_clients=total_clients)
    except Exception as e:
        flash(_("flash_pihole_error", error=str(e)), "error")
        return render_template("dashboard.html", s=None, blocking=None,
                             history=None, active_clients=0, total_clients=0)

@app.post("/toggle-blocking")
def toggle_blocking():
    want = request.form.get("enable") == "1"
    timer = request.form.get("timer")
    timer = int(timer) if (timer and not want) else None
    api.set_blocking(want, timer_seconds=timer)
    flash(_("flash_blocking_updated"), "ok")
    return redirect(url_for("dashboard"))

@app.get("/lists")
def lists_view():
    lists = []
    err = None
    try:
        lists = api.lists()
    except Exception as e:
        err = str(e)

    # Get all schedules and group by list address
    schedules = schedules_db.get_all_schedules()
    schedules_by_list = {}
    for schedule in schedules:
        if schedule['list_address'] not in schedules_by_list:
            schedules_by_list[schedule['list_address']] = []
        schedules_by_list[schedule['list_address']].append(schedule)

    return render_template("lists.html", lists=lists, err=err,
                         schedules_by_list=schedules_by_list, system_tz=system_tz)

@app.post("/lists/add")
def lists_add():
    address = request.form.get("address", "").strip()
    ltype = request.form.get("type", "block")
    enabled = request.form.get("enabled") == "1"
    api.add_list(address, list_type=ltype, enabled=enabled)
    flash(_("flash_list_added"), "ok")
    return redirect(url_for("lists_view"))

@app.post("/lists/toggle")
def lists_toggle():
    address = request.form.get("address")
    enabled = request.form.get("enabled") == "1"
    api.set_list_enabled(address, enabled)
    return jsonify({"ok": True})

@app.post("/lists/delete")
def lists_delete():
    address = request.form.get("address")
    api.delete_list(address)
    flash(_("flash_list_removed"), "ok")
    return redirect(url_for("lists_view"))

@app.get("/domains")
def domains_view():
    domains = []
    err = None
    try:
        domains = api.domains()
    except Exception as e:
        err = str(e)
    return render_template("domains.html", domains=domains, err=err)

@app.post("/domains/add")
def domains_add():
    user_input = request.form.get("domain", "").strip()
    list_type = request.form.get("type", "deny")
    enabled = request.form.get("enabled") == "1"

    # Convert user input to regex pattern
    # Example: cdn.advg.agency -> (\.|^)cdn\.advg\.agency$
    escaped_domain = user_input.replace(".", r"\.")
    regex_domain = rf"(\.|^){escaped_domain}$"

    # Use original input as comment, regex pattern as domain
    api.add_domain(regex_domain, list_type=list_type, kind="regex", enabled=enabled, comment=user_input)
    flash(_("flash_domain_saved"), "ok")
    return redirect(url_for("domains_view"))

@app.post("/domains/toggle")
def domains_toggle():
    list_type = request.form.get("type")
    kind = request.form.get("kind")
    domain = request.form.get("domain")
    enabled = request.form.get("enabled") == "1"
    api.set_domain_enabled(list_type, kind, domain, enabled)
    return jsonify({"ok": True})

@app.post("/domains/delete")
def domains_delete():
    list_type = request.form.get("type", "deny")
    kind = request.form.get("kind", "exact")
    domain = request.form.get("domain")
    api.delete_domain(list_type=list_type, kind=kind, domain=domain)
    flash(_("flash_domain_removed"), "ok")
    return redirect(url_for("domains_view"))

@app.post("/schedules/add")
def schedules_add():
    """Create a new schedule"""
    list_address = request.form.get("list_address")
    list_name = request.form.get("list_name")
    action = request.form.get("action")
    schedule_type = request.form.get("schedule_type")
    time_str = request.form.get("time")
    days = request.form.getlist("days[]") if schedule_type == 'weekly' else None

    try:
        schedule_id = schedules_db.create_schedule(
            list_address, list_name, action, schedule_type, time_str, days, system_tz
        )
        schedule = schedules_db.get_schedule(schedule_id)
        schedule_manager.add_schedule(schedule)

        flash(_("flash_schedule_created", action=action, list_name=list_name, schedule_type=schedule_type, time=time_str), "ok")
    except Exception as e:
        flash(_("flash_schedule_error", error=str(e)), "error")

    return redirect(url_for("lists_view"))

@app.post("/schedules/toggle")
def schedules_toggle():
    """Enable/disable a schedule without deleting it"""
    schedule_id = int(request.form.get("schedule_id"))
    enabled = request.form.get("enabled") == "1"

    try:
        schedules_db.update_schedule(schedule_id, enabled=enabled)

        if enabled:
            schedule = schedules_db.get_schedule(schedule_id)
            schedule_manager.add_schedule(schedule)
        else:
            schedule_manager.remove_schedule(schedule_id)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

    return jsonify({"ok": True})

@app.post("/schedules/delete")
def schedules_delete():
    """Delete a schedule"""
    schedule_id = int(request.form.get("schedule_id"))

    try:
        schedule_manager.remove_schedule(schedule_id)
    except:
        pass  # Job might not exist in scheduler

    schedules_db.delete_schedule(schedule_id)
    flash(_("flash_schedule_deleted"), "ok")
    return redirect(url_for("lists_view"))

if __name__ == "__main__":
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", 8088))
    app.run(host=host, port=port)
