"""
CLI helper to run Pi-hole actions on schedule.
Usage examples:
  python3 cli_task.py --action list-enable --address https://example.com/hosts --enable 1
  python3 cli_task.py --action list-enable --address https://example.com/hosts --enable 0
  python3 cli_task.py --action domain --type deny --domain youtube.com --enable 0
  python3 cli_task.py --action global-block --enable 0 --timer 300
Env:
  PIHOLE_BASE_URL, PIHOLE_PASSWORD (same as the Flask app)
"""
import os
import argparse
from pihole_api import PiHoleAPI

BASE = os.environ.get("PIHOLE_BASE_URL", "http://pi.hole")
PWD  = os.environ.get("PIHOLE_PASSWORD", "")

parser = argparse.ArgumentParser()
parser.add_argument("--action", required=True, choices=["list-enable","domain","global-block"])
parser.add_argument("--address")
parser.add_argument("--domain")
parser.add_argument("--type", choices=["allow","deny","block","allowlist","denylist"], default="deny")
parser.add_argument("--enable", type=int, choices=[0,1])
parser.add_argument("--timer", type=int)
args = parser.parse_args()

api = PiHoleAPI(BASE, PWD)

if args.action == "list-enable":
    if not args.address or args.enable is None:
        raise SystemExit("--address and --enable required")
    api.set_list_enabled(args.address, bool(args.enable))

elif args.action == "domain":
    if not args.domain or args.enable is None:
        raise SystemExit("--domain and --enable required")
    # For simplicity: add to deny/allow list with desired state (idempotent enough for most cases)
    api.add_domain(args.domain, list_type=("allow" if args.type.startswith("allow") else "deny"), enabled=bool(args.enable))

elif args.action == "global-block":
    if args.enable is None:
        raise SystemExit("--enable required")
    api.set_blocking(bool(args.enable), timer_seconds=args.timer)