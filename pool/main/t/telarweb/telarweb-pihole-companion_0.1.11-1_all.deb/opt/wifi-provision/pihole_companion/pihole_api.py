import time
import requests
from urllib.parse import quote

class PiHoleAPI:
    """
    Minimal Pi-hole API client.
    - Prefers v6 REST API (/api) with session auth
    - Falls back to v5 PHP API (/admin/api.php) for core actions

    NOTE (v6): Domains are addressed by **type/kind/domain** (no numeric ID).
    type ∈ {"allow","deny"}; kind ∈ {"exact","regex"}.
    See Pi-hole v6 docs: /api/domains/{type}/{kind}/{domain}
    """

    def __init__(self, base_url: str, password: str, timeout=6):
        self.base_url = base_url.rstrip('/')
        self.password = password
        self.timeout = timeout
        self.sid = None
        self.csrf = None
        self.last_auth = 0
        self._v6_conclusive = False
        # Probe v6 – retry up to 3 times to survive transient network unavailability at boot
        self.v6 = self._probe_v6()

    def _probe_v6(self, retries=3, delay=5) -> bool:
        for attempt in range(retries):
            try:
                r = requests.get(f"{self.base_url}/api/dns/blocking", timeout=self.timeout)
                self._v6_conclusive = True
                return r.status_code != 404
            except Exception:
                if attempt < retries - 1:
                    time.sleep(delay)
        self._v6_conclusive = False
        return False

    def _ensure_v6_detected(self):
        """Re-probe v6 if initial detection failed due to network errors."""
        if not self._v6_conclusive:
            self.v6 = self._probe_v6(retries=1, delay=0)

    # ---------- helpers ----------
    def _auth_v6(self, force: bool = False):
        now = time.time()
        if not force and self.sid and (now - self.last_auth) < 240:  # keep-alive ~4 min
            return
        resp = requests.post(
            f"{self.base_url}/api/auth",
            json={"password": self.password},
            timeout=self.timeout,
        )
        resp.raise_for_status()
        data = resp.json().get("session", {})
        self.sid = data.get("sid")
        self.csrf = data.get("csrf")
        self.last_auth = time.time()
        if not self.sid:
            raise RuntimeError("Failed to authenticate to Pi-hole v6 API")

    def _headers_v6(self):
        return {"X-FTL-SID": self.sid, "X-FTL-CSRF": self.csrf} if self.sid and self.csrf else {}

    def _v6_request(self, method: str, path: str, **kwargs):
        """Authenticated v6 request with one retry on a stale session.

        Pi-hole drops all sessions when FTL restarts (config change, gravity
        update, nightly maintenance). Without the 401 retry we would keep
        sending the dead SID for up to 4 minutes and every call would fail.
        """
        self._auth_v6()
        url = f"{self.base_url}{path}"
        r = requests.request(method, url, headers=self._headers_v6(),
                             timeout=self.timeout, **kwargs)
        if r.status_code == 401:
            self._auth_v6(force=True)
            r = requests.request(method, url, headers=self._headers_v6(),
                                 timeout=self.timeout, **kwargs)
        r.raise_for_status()
        return r

    # ---------- dashboard ----------
    def summary(self):
        self._ensure_v6_detected()
        if self.v6:
            j = self._v6_request("GET", "/api/stats/summary").json()

            # Extract data from nested Pi-hole v6 API response structure
            queries = j.get("queries", {})
            gravity = j.get("gravity", {})
            clients = j.get("clients", {})

            return {
                "total_queries": queries.get("total"),
                "queries_blocked": queries.get("blocked"),
                "percent_blocked": queries.get("percent_blocked"),
                "domains_on_lists": gravity.get("domains_being_blocked"),
                "active_clients": clients.get("active", 0),
                "total_clients": clients.get("total", 0),
            }
        else:
            r = requests.get(f"{self.base_url}/admin/api.php", params={"summaryRaw": "", "auth": self.password}, timeout=self.timeout)
            r.raise_for_status()
            j = r.json()

            return {
                "total_queries": j.get("dns_queries_today"),
                "queries_blocked": j.get("ads_blocked_today"),
                "percent_blocked": j.get("ads_percentage_today"),
                "domains_on_lists": j.get("domains_being_blocked"),
                # v5: unique_clients = clients seen today (≈ active),
                # clients_ever_seen = all clients ever (≈ total).
                "active_clients": j.get("unique_clients", 0),
                "total_clients": j.get("clients_ever_seen", 0),
            }

    def get_history(self):
        """Get history data for last 24 hours"""
        self._ensure_v6_detected()
        if self.v6:
            return self._v6_request("GET", "/api/history").json()
        else:
            # v5 fallback: get queries over time
            r = requests.get(f"{self.base_url}/admin/api.php", params={"overTimeDataForGraph": "", "auth": self.password}, timeout=self.timeout)
            r.raise_for_status()
            return r.json()

    # ---------- global blocking ----------
    def get_blocking(self) -> bool:
        self._ensure_v6_detected()
        if self.v6:
            blocking = self._v6_request("GET", "/api/dns/blocking").json().get("blocking")
            # Pi-hole v6 returns "enabled"/"disabled" strings or True/False boolean
            if isinstance(blocking, str):
                return blocking.lower() == "enabled"
            return bool(blocking)
        else:
            r = requests.get(f"{self.base_url}/admin/api.php", params={"status": "", "auth": self.password}, timeout=self.timeout)
            r.raise_for_status()
            return r.json().get("status") == "enabled"

    def set_blocking(self, enable: bool, timer_seconds: int | None = None):
        self._ensure_v6_detected()
        if self.v6:
            payload = {"blocking": bool(enable)}
            if not enable and timer_seconds:
                payload["timer"] = int(timer_seconds)
            r = self._v6_request("POST", "/api/dns/blocking", json=payload)
            return r.json() if r.text else {"ok": True}
        else:
            params = {"auth": self.password}
            if enable:
                params["enable"] = ""
            else:
                params["disable"] = int(timer_seconds) if timer_seconds else ""
            r = requests.get(f"{self.base_url}/admin/api.php", params=params, timeout=self.timeout)
            r.raise_for_status()
            return {"ok": True}

    # ---------- subscribed lists (adlists) ----------
    def lists(self):
        self._ensure_v6_detected()
        if not self.v6:
            raise RuntimeError("Subscribed lists API requires Pi-hole v6")
        return self._v6_request("GET", "/api/lists").json().get("lists", [])

    def add_list(self, address: str, list_type: str = "block", enabled: bool = True, groups: list[int] | None = None):
        self._ensure_v6_detected()
        if not self.v6:
            raise RuntimeError("Subscribed lists API requires Pi-hole v6")
        payload = {"address": address, "type": list_type, "enabled": bool(enabled)}
        if groups:
            payload["groups"] = groups
        return self._v6_request("POST", "/api/lists", json=payload).json()

    def set_list_enabled(self, address: str, enabled: bool):
        self._ensure_v6_detected()
        if not self.v6:
            raise RuntimeError("Subscribed lists API requires Pi-hole v6")

        # First, get the current list to retrieve its type and other properties
        lists = self.lists()
        current_list = next((l for l in lists if l.get('address') == address), None)

        if not current_list:
            raise RuntimeError(f"List not found: {address}")

        # Update with the new enabled state, preserving all other properties
        payload = {
            "enabled": bool(enabled),
            "type": current_list.get("type", "block")
        }

        # Preserve comment if it exists
        if current_list.get("comment"):
            payload["comment"] = current_list["comment"]

        r = self._v6_request("PUT", f"/api/lists/{quote(address, safe='')}", json=payload)
        return r.json() if r.text else {"ok": True}

    def delete_list(self, address: str):
        self._ensure_v6_detected()
        if not self.v6:
            raise RuntimeError("Subscribed lists API requires Pi-hole v6")
        self._v6_request("DELETE", f"/api/lists/{quote(address, safe='')}")
        return {"ok": True}

    # ---------- domain allow/deny ----------
    def domains(self):
        self._ensure_v6_detected()
        if self.v6:
            return self._v6_request("GET", "/api/domains").json().get("domains", [])
        else:
            # v5 has no clean list endpoint; return empty and rely on add/remove only
            return []

    def add_domain(self, domain: str, list_type: str = "deny", kind: str = "exact", enabled: bool = True, comment: str | None = None, groups: list[int] | None = None):
        list_type = "allow" if list_type.startswith("allow") else "deny"
        kind = "regex" if kind.startswith("regex") else "exact"
        self._ensure_v6_detected()
        if self.v6:
            payload = {}
            if enabled is not None:
                payload["enabled"] = bool(enabled)
            if comment:
                payload["comment"] = comment
            if groups:
                payload["groups"] = groups
            path = f"/api/domains/{list_type}/{kind}/{quote(domain, safe='')}"
            r = self._v6_request("PUT", path, json=(payload or None))
            return r.json() if r.text else {"ok": True}
        else:
            # v5 fallback: exact allow/deny only via admin API
            params = {"list": list_type, "add": domain, "auth": self.password}
            r = requests.get(f"{self.base_url}/admin/api.php", params=params, timeout=self.timeout)
            r.raise_for_status()
            return {"ok": True}

    def set_domain_enabled(self, list_type: str, kind: str, domain: str, enabled: bool):
        list_type = "allow" if list_type.startswith("allow") else "deny"
        kind = "regex" if kind.startswith("regex") else "exact"
        self._ensure_v6_detected()
        if not self.v6:
            raise RuntimeError("Toggling domain enabled state requires Pi-hole v6")

        # First, get the current domain to retrieve its comment and other properties
        domains = self.domains()
        current_domain = next((d for d in domains if d.get('domain') == domain and d.get('type') == list_type and d.get('kind') == kind), None)

        if not current_domain:
            raise RuntimeError(f"Domain not found: {domain}")

        # Update with the new enabled state, preserving all other properties
        payload = {
            "enabled": bool(enabled),
            "type": list_type,
            "kind": kind,
            "groups": [0]
        }

        # Preserve comment if it exists
        if current_domain.get("comment"):
            payload["comment"] = current_domain["comment"]

        path = f"/api/domains/{list_type}/{kind}/{quote(domain, safe='')}"
        r = self._v6_request("PUT", path, json=payload)
        return r.json() if r.text else {"ok": True}

    def delete_domain(self, list_type: str, kind: str, domain: str):
        list_type = "allow" if list_type.startswith("allow") else "deny"
        kind = "regex" if kind.startswith("regex") else "exact"
        self._ensure_v6_detected()
        if self.v6:
            self._v6_request("DELETE", f"/api/domains/{list_type}/{kind}/{quote(domain, safe='')}")
            return {"ok": True}
        else:
            # v5 fallback: exact allow/deny only
            params = {"list": list_type, "remove": domain, "auth": self.password}
            r = requests.get(f"{self.base_url}/admin/api.php", params=params, timeout=self.timeout)
            r.raise_for_status()
            return {"ok": True}
